var class_insert_cinema_page =
[
    [ "reset", "class_insert_cinema_page.html#a8c28accd82b75be9bb31cbe43dafc947", null ],
    [ "resizeEvent", "class_insert_cinema_page.html#a548ddc0d623517c0a369e05594c2527e", null ]
];