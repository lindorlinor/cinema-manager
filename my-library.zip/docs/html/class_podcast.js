var class_podcast =
[
    [ "aggiornaDate", "class_podcast.html#a3d25a1b7dac3e513f268531b40c9723c", null ],
    [ "aggiungiLingua", "class_podcast.html#aa8e82b12fef6a345274773694f5f03b7", null ],
    [ "aggiungiPuntata", "class_podcast.html#ae54f2234e47f248098762fe07cbe36de", null ],
    [ "calcolaIncasso", "class_podcast.html#a8a39f58c02ee6b4235f1a1afe2f5bc8d", null ],
    [ "estendiDataFineRilascio", "class_podcast.html#a188a639aa2d972a5f4ab038577078654", null ],
    [ "rimuoviPuntata", "class_podcast.html#ad5725236ae9d986fcffb9b1dab0043b5", null ]
];