var searchData=
[
  ['savemedia_0',['saveMedia',['../class_media_manager_json.html#ae8a5ddec6e9a70eba5fe3aa7cec1a8cb',1,'MediaManagerJson']]],
  ['setdatafinerilascio_1',['setDataFineRilascio',['../class_film.html#aefbbd20e9554d424f553fe5cb9fd6a4f',1,'Film::setDataFineRilascio()'],['../class_puntata.html#a61c96f3fd3392d9f61da1ad8b827223b',1,'Puntata::setDataFineRilascio()'],['../class_trailer.html#a4389dd02c6a2727e6c483abab67e4d80',1,'Trailer::setDataFineRilascio()']]],
  ['setdatainiziorilascio_2',['setDataInizioRilascio',['../class_puntata.html#a7a716689f5a17be81e797ff577998d6f',1,'Puntata']]],
  ['setnomecinema_3',['setNomeCinema',['../class_media_manager_json.html#a576d6fa690a19b7e7511a620e48b683e',1,'MediaManagerJson']]]
];
