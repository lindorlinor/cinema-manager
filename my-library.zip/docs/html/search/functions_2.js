var searchData=
[
  ['disaccoppiatrailer_0',['disaccoppiaTrailer',['../class_film.html#a6e741e83e292cb8f85712dfd4196d925',1,'Film']]],
  ['duratacampagna_1',['DurataCampagna',['../class_media.html#a0dcb4941c952295b53e3ff31af1e367b',1,'Media']]]
];
