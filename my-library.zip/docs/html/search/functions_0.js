var searchData=
[
  ['aggiornadate_0',['aggiornaDate',['../class_podcast.html#a3d25a1b7dac3e513f268531b40c9723c',1,'Podcast']]],
  ['aggiungilingua_1',['aggiungiLingua',['../class_podcast.html#aa8e82b12fef6a345274773694f5f03b7',1,'Podcast::aggiungiLingua()'],['../class_puntata.html#afbe4686838531a3d54b740cc2c4ade3d',1,'Puntata::aggiungiLingua()']]],
  ['aggiungipuntata_2',['aggiungiPuntata',['../class_podcast.html#ae54f2234e47f248098762fe07cbe36de',1,'Podcast']]],
  ['associafilm_3',['associaFilm',['../class_trailer.html#a347f0cde69e32f63508f2997fbc44dec',1,'Trailer']]],
  ['associapodcast_4',['associaPodcast',['../class_puntata.html#a3b78b39eb440dae6cc8b0402fdb8699c',1,'Puntata']]]
];
