var searchData=
[
  ['refreshcinemabuttons_0',['refreshCinemaButtons',['../class_cinema_selection_page.html#a2b8adba516bf563a4a87c03ee35f706b',1,'CinemaSelectionPage']]],
  ['remove_1',['remove',['../class_media_manager_json.html#a87bead89d7ca4de3625223cc2a3fdf31',1,'MediaManagerJson']]],
  ['reset_2',['reset',['../class_insert_cinema_page.html#a8c28accd82b75be9bb31cbe43dafc947',1,'InsertCinemaPage']]],
  ['resizeevent_3',['resizeEvent',['../class_insert_cinema_page.html#a548ddc0d623517c0a369e05594c2527e',1,'InsertCinemaPage']]],
  ['rimuovipuntata_4',['rimuoviPuntata',['../class_podcast.html#ad5725236ae9d986fcffb9b1dab0043b5',1,'Podcast']]],
  ['rimuovitrailer_5',['rimuoviTrailer',['../class_film.html#a804f4e60c7f804ca9934ec81d8cd761a',1,'Film']]]
];
