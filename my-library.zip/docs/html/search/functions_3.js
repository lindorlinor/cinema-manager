var searchData=
[
  ['estendidatafinerilascio_0',['estendiDataFineRilascio',['../class_film.html#acfe82dd1cf9eeecc645ba5159b2ce698',1,'Film::estendiDataFineRilascio()'],['../class_inserzione.html#ac21c85015bddc4dd881cf5cc47f15a41',1,'Inserzione::estendiDataFineRilascio()'],['../class_media.html#a957bf71135599ba62d4a2b3e41a50a8d',1,'Media::estendiDataFineRilascio()'],['../class_podcast.html#a188a639aa2d972a5f4ab038577078654',1,'Podcast::estendiDataFineRilascio()'],['../class_puntata.html#a806af1f704b620f35813086d97acb380',1,'Puntata::estendiDataFineRilascio()'],['../class_trailer.html#a02ed1e6868de35aa937fb5a49a7d2b47',1,'Trailer::estendiDataFineRilascio()']]]
];
