var indexSectionsWithContent =
{
  0: "abcdefgilmnoprstuvwx",
  1: "abcdefgilmnoprstuvwx",
  2: "e",
  3: "acdefilmrsu",
  4: "m"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "Tutto",
  1: "Classi",
  2: "File",
  3: "Funzioni",
  4: "Variabili"
};

