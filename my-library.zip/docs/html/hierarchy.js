var hierarchy =
[
    [ "Approx", "class_approx.html", null ],
    [ "Catch::Detail::Approx", "class_catch_1_1_detail_1_1_approx.html", null ],
    [ "Catch::Generators::as< T >", "struct_catch_1_1_generators_1_1as.html", null ],
    [ "Catch::AssertionHandler", "class_catch_1_1_assertion_handler.html", null ],
    [ "Catch::AssertionInfo", "struct_catch_1_1_assertion_info.html", null ],
    [ "Catch::AssertionReaction", "struct_catch_1_1_assertion_reaction.html", null ],
    [ "Catch::Capturer", "class_catch_1_1_capturer.html", null ],
    [ "Catch::Matchers::StdString::CasedString", "struct_catch_1_1_matchers_1_1_std_string_1_1_cased_string.html", null ],
    [ "Catch::CaseSensitive", "struct_catch_1_1_case_sensitive.html", null ],
    [ "Catch_global_namespace_dummy", "struct_catch__global__namespace__dummy.html", null ],
    [ "CinemaData", "struct_cinema_data.html", [
      [ "MediaData", "struct_media_data.html", [
        [ "FilmData", "struct_film_data.html", null ],
        [ "PodcastData", "struct_podcast_data.html", null ],
        [ "PubblicitaData", "struct_pubblicita_data.html", [
          [ "InserzioneData", "struct_inserzione_data.html", null ],
          [ "TrailerData", "struct_trailer_data.html", null ]
        ] ],
        [ "PuntataData", "struct_puntata_data.html", null ]
      ] ]
    ] ],
    [ "Converter", "class_converter.html", [
      [ "ConverterXml", "class_converter_xml.html", null ]
    ] ],
    [ "Catch::Counts", "struct_catch_1_1_counts.html", null ],
    [ "Catch::Decomposer", "struct_catch_1_1_decomposer.html", null ],
    [ "Catch::Detail::EnumInfo", "struct_catch_1_1_detail_1_1_enum_info.html", null ],
    [ "std::exception", null, [
      [ "Catch::GeneratorException", "class_catch_1_1_generator_exception.html", null ]
    ] ],
    [ "Catch::ExceptionTranslatorRegistrar", "class_catch_1_1_exception_translator_registrar.html", null ],
    [ "Catch::ExprLhs< LhsT >", "class_catch_1_1_expr_lhs.html", null ],
    [ "std::false_type", null, [
      [ "Catch::detail::is_range_impl< T, typename void_type< decltype(begin(std::declval< T >()))>::type >", "struct_catch_1_1detail_1_1is__range__impl_3_01_t_00_01typename_01void__type_3_01decltype_07begin8604ecb9de16ea7789f2f694ac896ffd.html", null ],
      [ "Catch::always_false< T >", "struct_catch_1_1always__false.html", null ],
      [ "Catch::detail::is_range_impl< T, typename >", "struct_catch_1_1detail_1_1is__range__impl.html", [
        [ "Catch::is_range< T >", "struct_catch_1_1is__range.html", null ]
      ] ]
    ] ],
    [ "Catch::Generators::GeneratorUntypedBase", "class_catch_1_1_generators_1_1_generator_untyped_base.html", [
      [ "Catch::Generators::IGenerator< std::vector< T > >", "struct_catch_1_1_generators_1_1_i_generator.html", [
        [ "Catch::Generators::ChunkGenerator< T >", "class_catch_1_1_generators_1_1_chunk_generator.html", null ]
      ] ],
      [ "Catch::Generators::IGenerator< Float >", "struct_catch_1_1_generators_1_1_i_generator.html", [
        [ "Catch::Generators::RandomFloatingGenerator< Float >", "class_catch_1_1_generators_1_1_random_floating_generator.html", null ]
      ] ],
      [ "Catch::Generators::IGenerator< Integer >", "struct_catch_1_1_generators_1_1_i_generator.html", [
        [ "Catch::Generators::RandomIntegerGenerator< Integer >", "class_catch_1_1_generators_1_1_random_integer_generator.html", null ]
      ] ],
      [ "Catch::Generators::IGenerator< T >", "struct_catch_1_1_generators_1_1_i_generator.html", [
        [ "Catch::Generators::FilterGenerator< T, Predicate >", "class_catch_1_1_generators_1_1_filter_generator.html", null ],
        [ "Catch::Generators::FixedValuesGenerator< T >", "class_catch_1_1_generators_1_1_fixed_values_generator.html", null ],
        [ "Catch::Generators::Generators< T >", "class_catch_1_1_generators_1_1_generators.html", null ],
        [ "Catch::Generators::IteratorGenerator< T >", "class_catch_1_1_generators_1_1_iterator_generator.html", null ],
        [ "Catch::Generators::MapGenerator< T, U, Func >", "class_catch_1_1_generators_1_1_map_generator.html", null ],
        [ "Catch::Generators::RangeGenerator< T >", "class_catch_1_1_generators_1_1_range_generator.html", null ],
        [ "Catch::Generators::RepeatGenerator< T >", "class_catch_1_1_generators_1_1_repeat_generator.html", null ],
        [ "Catch::Generators::SingleValueGenerator< T >", "class_catch_1_1_generators_1_1_single_value_generator.html", null ],
        [ "Catch::Generators::TakeGenerator< T >", "class_catch_1_1_generators_1_1_take_generator.html", null ]
      ] ]
    ] ],
    [ "Catch::Generators::GeneratorWrapper< T >", "class_catch_1_1_generators_1_1_generator_wrapper.html", null ],
    [ "Catch::IContext", "struct_catch_1_1_i_context.html", [
      [ "Catch::IMutableContext", "struct_catch_1_1_i_mutable_context.html", null ]
    ] ],
    [ "Catch::IExceptionTranslator", "struct_catch_1_1_i_exception_translator.html", null ],
    [ "Catch::IExceptionTranslatorRegistry", "struct_catch_1_1_i_exception_translator_registry.html", null ],
    [ "Catch::IGeneratorTracker", "struct_catch_1_1_i_generator_tracker.html", null ],
    [ "Catch::IMutableEnumValuesRegistry", "struct_catch_1_1_i_mutable_enum_values_registry.html", null ],
    [ "Catch::IMutableRegistryHub", "struct_catch_1_1_i_mutable_registry_hub.html", null ],
    [ "Catch::IRegistryHub", "struct_catch_1_1_i_registry_hub.html", null ],
    [ "Catch::IResultCapture", "struct_catch_1_1_i_result_capture.html", null ],
    [ "Catch::IRunner", "struct_catch_1_1_i_runner.html", null ],
    [ "Catch::is_callable< T >", "struct_catch_1_1is__callable.html", null ],
    [ "Catch::is_callable< Fun(Args...)>", "struct_catch_1_1is__callable_3_01_fun_07_args_8_8_8_08_4.html", null ],
    [ "Catch::is_callable_tester", "struct_catch_1_1is__callable__tester.html", null ],
    [ "Catch::Detail::IsStreamInsertable< T >", "class_catch_1_1_detail_1_1_is_stream_insertable.html", null ],
    [ "Catch::IStream", "struct_catch_1_1_i_stream.html", null ],
    [ "Catch::ITestCaseRegistry", "struct_catch_1_1_i_test_case_registry.html", null ],
    [ "Catch::ITestInvoker", "struct_catch_1_1_i_test_invoker.html", [
      [ "Catch::TestInvokerAsMethod< C >", "class_catch_1_1_test_invoker_as_method.html", null ]
    ] ],
    [ "Catch::ITransientExpression", "struct_catch_1_1_i_transient_expression.html", [
      [ "Catch::BinaryExpr< LhsT, RhsT >", "class_catch_1_1_binary_expr.html", null ],
      [ "Catch::MatchExpr< ArgT, MatcherT >", "class_catch_1_1_match_expr.html", null ],
      [ "Catch::UnaryExpr< LhsT >", "class_catch_1_1_unary_expr.html", null ]
    ] ],
    [ "Catch::LazyExpression", "class_catch_1_1_lazy_expression.html", null ],
    [ "Catch::Matchers::Impl::MatcherMethod< ObjectT >", "struct_catch_1_1_matchers_1_1_impl_1_1_matcher_method.html", [
      [ "Catch::Matchers::Impl::MatcherBase< std::string >", "struct_catch_1_1_matchers_1_1_impl_1_1_matcher_base.html", null ]
    ] ],
    [ "Catch::Matchers::Impl::MatcherMethod< ArgT >", "struct_catch_1_1_matchers_1_1_impl_1_1_matcher_method.html", [
      [ "Catch::Matchers::Impl::MatcherBase< ArgT >", "struct_catch_1_1_matchers_1_1_impl_1_1_matcher_base.html", [
        [ "Catch::Matchers::Impl::MatchAllOf< ArgT >", "struct_catch_1_1_matchers_1_1_impl_1_1_match_all_of.html", null ],
        [ "Catch::Matchers::Impl::MatchAnyOf< ArgT >", "struct_catch_1_1_matchers_1_1_impl_1_1_match_any_of.html", null ],
        [ "Catch::Matchers::Impl::MatchNotOf< ArgT >", "struct_catch_1_1_matchers_1_1_impl_1_1_match_not_of.html", null ]
      ] ]
    ] ],
    [ "Catch::Matchers::Impl::MatcherMethod< double >", "struct_catch_1_1_matchers_1_1_impl_1_1_matcher_method.html", [
      [ "Catch::Matchers::Impl::MatcherBase< double >", "struct_catch_1_1_matchers_1_1_impl_1_1_matcher_base.html", null ]
    ] ],
    [ "Catch::Matchers::Impl::MatcherMethod< std::exception >", "struct_catch_1_1_matchers_1_1_impl_1_1_matcher_method.html", [
      [ "Catch::Matchers::Impl::MatcherBase< std::exception >", "struct_catch_1_1_matchers_1_1_impl_1_1_matcher_base.html", null ]
    ] ],
    [ "Catch::Matchers::Impl::MatcherMethod< T >", "struct_catch_1_1_matchers_1_1_impl_1_1_matcher_method.html", [
      [ "Catch::Matchers::Impl::MatcherBase< std::vector< T, AllocMatch > >", "struct_catch_1_1_matchers_1_1_impl_1_1_matcher_base.html", null ],
      [ "Catch::Matchers::Impl::MatcherBase< std::vector< T, Alloc > >", "struct_catch_1_1_matchers_1_1_impl_1_1_matcher_base.html", null ],
      [ "Catch::Matchers::Impl::MatcherBase< T >", "struct_catch_1_1_matchers_1_1_impl_1_1_matcher_base.html", [
        [ "Catch::Matchers::Exception::ExceptionMessageMatcher", "class_catch_1_1_matchers_1_1_exception_1_1_exception_message_matcher.html", null ],
        [ "Catch::Matchers::Floating::WithinAbsMatcher", "struct_catch_1_1_matchers_1_1_floating_1_1_within_abs_matcher.html", null ],
        [ "Catch::Matchers::Floating::WithinRelMatcher", "struct_catch_1_1_matchers_1_1_floating_1_1_within_rel_matcher.html", null ],
        [ "Catch::Matchers::Floating::WithinUlpsMatcher", "struct_catch_1_1_matchers_1_1_floating_1_1_within_ulps_matcher.html", null ],
        [ "Catch::Matchers::Generic::PredicateMatcher< T >", "class_catch_1_1_matchers_1_1_generic_1_1_predicate_matcher.html", null ],
        [ "Catch::Matchers::StdString::RegexMatcher", "struct_catch_1_1_matchers_1_1_std_string_1_1_regex_matcher.html", null ],
        [ "Catch::Matchers::StdString::StringMatcherBase", "struct_catch_1_1_matchers_1_1_std_string_1_1_string_matcher_base.html", [
          [ "Catch::Matchers::StdString::ContainsMatcher", "struct_catch_1_1_matchers_1_1_std_string_1_1_contains_matcher.html", null ],
          [ "Catch::Matchers::StdString::EndsWithMatcher", "struct_catch_1_1_matchers_1_1_std_string_1_1_ends_with_matcher.html", null ],
          [ "Catch::Matchers::StdString::EqualsMatcher", "struct_catch_1_1_matchers_1_1_std_string_1_1_equals_matcher.html", null ],
          [ "Catch::Matchers::StdString::StartsWithMatcher", "struct_catch_1_1_matchers_1_1_std_string_1_1_starts_with_matcher.html", null ]
        ] ],
        [ "Catch::Matchers::Vector::ApproxMatcher< T, AllocComp, AllocMatch >", "struct_catch_1_1_matchers_1_1_vector_1_1_approx_matcher.html", null ],
        [ "Catch::Matchers::Vector::ContainsElementMatcher< T, Alloc >", "struct_catch_1_1_matchers_1_1_vector_1_1_contains_element_matcher.html", null ],
        [ "Catch::Matchers::Vector::ContainsMatcher< T, AllocComp, AllocMatch >", "struct_catch_1_1_matchers_1_1_vector_1_1_contains_matcher.html", null ],
        [ "Catch::Matchers::Vector::EqualsMatcher< T, AllocComp, AllocMatch >", "struct_catch_1_1_matchers_1_1_vector_1_1_equals_matcher.html", null ],
        [ "Catch::Matchers::Vector::UnorderedEqualsMatcher< T, AllocComp, AllocMatch >", "struct_catch_1_1_matchers_1_1_vector_1_1_unordered_equals_matcher.html", null ]
      ] ]
    ] ],
    [ "Catch::Matchers::Impl::MatcherUntypedBase", "class_catch_1_1_matchers_1_1_impl_1_1_matcher_untyped_base.html", [
      [ "Catch::Matchers::Impl::MatcherBase< std::string >", "struct_catch_1_1_matchers_1_1_impl_1_1_matcher_base.html", null ],
      [ "Catch::Matchers::Impl::MatcherBase< std::exception >", "struct_catch_1_1_matchers_1_1_impl_1_1_matcher_base.html", null ],
      [ "Catch::Matchers::Impl::MatcherBase< double >", "struct_catch_1_1_matchers_1_1_impl_1_1_matcher_base.html", null ],
      [ "Catch::Matchers::Impl::MatcherBase< ArgT >", "struct_catch_1_1_matchers_1_1_impl_1_1_matcher_base.html", null ],
      [ "Catch::Matchers::Impl::MatcherBase< std::vector< T, AllocMatch > >", "struct_catch_1_1_matchers_1_1_impl_1_1_matcher_base.html", null ],
      [ "Catch::Matchers::Impl::MatcherBase< std::vector< T, Alloc > >", "struct_catch_1_1_matchers_1_1_impl_1_1_matcher_base.html", null ],
      [ "Catch::Matchers::Impl::MatcherBase< T >", "struct_catch_1_1_matchers_1_1_impl_1_1_matcher_base.html", null ]
    ] ],
    [ "Media", "class_media.html", [
      [ "Film", "class_film.html", null ],
      [ "Podcast", "class_podcast.html", null ],
      [ "Pubblicita", "class_pubblicita.html", [
        [ "Inserzione", "class_inserzione.html", null ],
        [ "Trailer", "class_trailer.html", null ]
      ] ],
      [ "Puntata", "class_puntata.html", null ]
    ] ],
    [ "MediaManagerXml", "class_media_manager_xml.html", null ],
    [ "MediaVisitor", "class_media_visitor.html", [
      [ "DetailPageVisitor", "class_detail_page_visitor.html", null ],
      [ "FlowVisitor", "class_flow_visitor.html", null ],
      [ "MediaUpdateVisitor", "class_media_update_visitor.html", null ],
      [ "XmlVisitor", "class_xml_visitor.html", null ]
    ] ],
    [ "Catch::MessageInfo", "struct_catch_1_1_message_info.html", null ],
    [ "Catch::MessageStream", "struct_catch_1_1_message_stream.html", [
      [ "Catch::MessageBuilder", "struct_catch_1_1_message_builder.html", null ]
    ] ],
    [ "Catch::NameAndTags", "struct_catch_1_1_name_and_tags.html", null ],
    [ "Catch::NonCopyable", "class_catch_1_1_non_copyable.html", [
      [ "Catch::AutoReg", "struct_catch_1_1_auto_reg.html", null ],
      [ "Catch::IConfig", "struct_catch_1_1_i_config.html", null ],
      [ "Catch::ReusableStringStream", "class_catch_1_1_reusable_string_stream.html", null ],
      [ "Catch::Section", "class_catch_1_1_section.html", null ]
    ] ],
    [ "Catch::Option< T >", "class_catch_1_1_option.html", null ],
    [ "Catch::pluralise", "struct_catch_1_1pluralise.html", null ],
    [ "QFrame", null, [
      [ "CinemaButton", "class_cinema_button.html", null ],
      [ "InsertImageFrame", "class_insert_image_frame.html", null ],
      [ "MediaFrame", "class_media_frame.html", null ],
      [ "PreviewCard", "class_preview_card.html", null ]
    ] ],
    [ "QLabel", null, [
      [ "ExpandableLabel", "class_expandable_label.html", null ]
    ] ],
    [ "QLayout", null, [
      [ "FlowLayout", "class_flow_layout.html", null ]
    ] ],
    [ "QMainWindow", null, [
      [ "MainWindow", "class_main_window.html", null ]
    ] ],
    [ "QObject", null, [
      [ "MediaManagerJson", "class_media_manager_json.html", null ]
    ] ],
    [ "QWidget", null, [
      [ "CinemaSelectionPage", "class_cinema_selection_page.html", null ],
      [ "DetailsPageButtons", "class_details_page_buttons.html", null ],
      [ "InsertCinemaPage", "class_insert_cinema_page.html", null ],
      [ "InsertMedia", "class_insert_media.html", null ],
      [ "ListPersone", "class_list_persone.html", null ],
      [ "MediaLibraryGenerale", "class_media_library_generale.html", null ],
      [ "MediaLibraryTutto", "class_media_library_tutto.html", null ],
      [ "MediaView", "class_media_view.html", [
        [ "FilmView", "class_film_view.html", null ],
        [ "TrailerView", "class_trailer_view.html", null ]
      ] ],
      [ "ScrollListWidget", "class_scroll_list_widget.html", null ],
      [ "SearchPanel", "class_search_panel.html", null ],
      [ "SelectMediaReference", "class_select_media_reference.html", null ]
    ] ],
    [ "Catch::RegistrarForTagAliases", "struct_catch_1_1_registrar_for_tag_aliases.html", null ],
    [ "Catch::ResultDisposition", "struct_catch_1_1_result_disposition.html", null ],
    [ "Catch::ResultWas", "struct_catch_1_1_result_was.html", null ],
    [ "Catch::RunTests", "struct_catch_1_1_run_tests.html", null ],
    [ "Catch::ScopedMessage", "class_catch_1_1_scoped_message.html", null ],
    [ "Catch::SectionEndInfo", "struct_catch_1_1_section_end_info.html", null ],
    [ "Catch::SectionInfo", "struct_catch_1_1_section_info.html", null ],
    [ "Catch::ShowDurations", "struct_catch_1_1_show_durations.html", null ],
    [ "Catch::SimplePcg32", "class_catch_1_1_simple_pcg32.html", null ],
    [ "Catch::SourceLineInfo", "struct_catch_1_1_source_line_info.html", null ],
    [ "Catch::StreamEndStop", "struct_catch_1_1_stream_end_stop.html", null ],
    [ "Catch::StringMaker< T, typename >", "struct_catch_1_1_string_maker.html", null ],
    [ "Catch::StringMaker< bool >", "struct_catch_1_1_string_maker_3_01bool_01_4.html", null ],
    [ "Catch::StringMaker< Catch::Detail::Approx >", "struct_catch_1_1_string_maker_3_01_catch_1_1_detail_1_1_approx_01_4.html", null ],
    [ "Catch::StringMaker< char * >", "struct_catch_1_1_string_maker_3_01char_01_5_01_4.html", null ],
    [ "Catch::StringMaker< char >", "struct_catch_1_1_string_maker_3_01char_01_4.html", null ],
    [ "Catch::StringMaker< char const * >", "struct_catch_1_1_string_maker_3_01char_01const_01_5_01_4.html", null ],
    [ "Catch::StringMaker< char[SZ]>", "struct_catch_1_1_string_maker_3_01char_0f_s_z_0e_4.html", null ],
    [ "Catch::StringMaker< double >", "struct_catch_1_1_string_maker_3_01double_01_4.html", null ],
    [ "Catch::StringMaker< float >", "struct_catch_1_1_string_maker_3_01float_01_4.html", null ],
    [ "Catch::StringMaker< int >", "struct_catch_1_1_string_maker_3_01int_01_4.html", null ],
    [ "Catch::StringMaker< long >", "struct_catch_1_1_string_maker_3_01long_01_4.html", null ],
    [ "Catch::StringMaker< long long >", "struct_catch_1_1_string_maker_3_01long_01long_01_4.html", null ],
    [ "Catch::StringMaker< R C::* >", "struct_catch_1_1_string_maker_3_01_r_01_c_1_1_5_01_4.html", null ],
    [ "Catch::StringMaker< R, typename std::enable_if< is_range< R >::value &&!::Catch::Detail::IsStreamInsertable< R >::value >::type >", "struct_catch_1_1_string_maker_3_01_r_00_01typename_01std_1_1enable__if_3_01is__range_3_01_r_01_4536d8fedfff6d62432b3dc59b56e1380.html", null ],
    [ "Catch::StringMaker< signed char >", "struct_catch_1_1_string_maker_3_01signed_01char_01_4.html", null ],
    [ "Catch::StringMaker< signed char[SZ]>", "struct_catch_1_1_string_maker_3_01signed_01char_0f_s_z_0e_4.html", null ],
    [ "Catch::StringMaker< std::nullptr_t >", "struct_catch_1_1_string_maker_3_01std_1_1nullptr__t_01_4.html", null ],
    [ "Catch::StringMaker< std::string >", "struct_catch_1_1_string_maker_3_01std_1_1string_01_4.html", null ],
    [ "Catch::StringMaker< std::wstring >", "struct_catch_1_1_string_maker_3_01std_1_1wstring_01_4.html", null ],
    [ "Catch::StringMaker< T * >", "struct_catch_1_1_string_maker_3_01_t_01_5_01_4.html", null ],
    [ "Catch::StringMaker< T[SZ]>", "struct_catch_1_1_string_maker_3_01_t_0f_s_z_0e_4.html", null ],
    [ "Catch::StringMaker< unsigned char >", "struct_catch_1_1_string_maker_3_01unsigned_01char_01_4.html", null ],
    [ "Catch::StringMaker< unsigned char[SZ]>", "struct_catch_1_1_string_maker_3_01unsigned_01char_0f_s_z_0e_4.html", null ],
    [ "Catch::StringMaker< unsigned int >", "struct_catch_1_1_string_maker_3_01unsigned_01int_01_4.html", null ],
    [ "Catch::StringMaker< unsigned long >", "struct_catch_1_1_string_maker_3_01unsigned_01long_01_4.html", null ],
    [ "Catch::StringMaker< unsigned long long >", "struct_catch_1_1_string_maker_3_01unsigned_01long_01long_01_4.html", null ],
    [ "Catch::StringMaker< wchar_t * >", "struct_catch_1_1_string_maker_3_01wchar__t_01_5_01_4.html", null ],
    [ "Catch::StringMaker< wchar_t const * >", "struct_catch_1_1_string_maker_3_01wchar__t_01const_01_5_01_4.html", null ],
    [ "Catch::StringRef", "class_catch_1_1_string_ref.html", null ],
    [ "Catch::TestCaseInfo", "struct_catch_1_1_test_case_info.html", [
      [ "Catch::TestCase", "class_catch_1_1_test_case.html", null ]
    ] ],
    [ "Catch::TestFailureException", "struct_catch_1_1_test_failure_exception.html", null ],
    [ "Catch::Timer", "class_catch_1_1_timer.html", null ],
    [ "Catch::Totals", "struct_catch_1_1_totals.html", null ],
    [ "std::true_type", null, [
      [ "Catch::detail::is_range_impl< T, typename void_type< decltype(begin(std::declval< T >()))>::type >", "struct_catch_1_1detail_1_1is__range__impl_3_01_t_00_01typename_01void__type_3_01decltype_07begin8604ecb9de16ea7789f2f694ac896ffd.html", null ],
      [ "Catch::true_given< typename >", "struct_catch_1_1true__given.html", null ]
    ] ],
    [ "Catch::UseColour", "struct_catch_1_1_use_colour.html", null ],
    [ "Catch::detail::void_type<... >", "struct_catch_1_1detail_1_1void__type.html", null ],
    [ "Catch::WaitForKeypress", "struct_catch_1_1_wait_for_keypress.html", null ],
    [ "Catch::WarnAbout", "struct_catch_1_1_warn_about.html", null ]
];