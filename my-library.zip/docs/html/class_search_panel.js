var class_search_panel =
[
    [ "updateModifierPanel", "class_search_panel.html#a4f2944a65a1d26544b7b9d31205a710b", null ]
];