var class_trailer =
[
    [ "associaFilm", "class_trailer.html#a347f0cde69e32f63508f2997fbc44dec", null ],
    [ "calcolaIncasso", "class_trailer.html#aeb0aeac66a2f71d240c593bd39019b66", null ],
    [ "estendiDataFineRilascio", "class_trailer.html#a02ed1e6868de35aa937fb5a49a7d2b47", null ],
    [ "setDataFineRilascio", "class_trailer.html#a4389dd02c6a2727e6c483abab67e4d80", null ]
];