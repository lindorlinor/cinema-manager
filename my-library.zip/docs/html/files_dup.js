var files_dup =
[
    [ "DataFiles", "dir_8935ce933ef1d0ae951f8892b8d6fbe5.html", "dir_8935ce933ef1d0ae951f8892b8d6fbe5" ],
    [ "GUI", "dir_171b764decf33d63a7df2fab4f4bc6d8.html", "dir_171b764decf33d63a7df2fab4f4bc6d8" ],
    [ "catch.hpp", "catch_8hpp_source.html", null ],
    [ "DetailPageVisitor.h", "_detail_page_visitor_8h_source.html", null ],
    [ "EnumClasses.h", "_enum_classes_8h.html", null ],
    [ "Film.h", "_film_8h_source.html", null ],
    [ "Inserzione.h", "_inserzione_8h_source.html", null ],
    [ "Media.h", "_media_8h_source.html", null ],
    [ "MediaVisitor.h", "_media_visitor_8h_source.html", null ],
    [ "Podcast.h", "_podcast_8h_source.html", null ],
    [ "Pubblicita.h", "_pubblicita_8h_source.html", null ],
    [ "Puntata.h", "_puntata_8h_source.html", null ],
    [ "Trailer.h", "_trailer_8h_source.html", null ]
];