var class_film =
[
    [ "calcolaIncasso", "class_film.html#abac6c22c8fc6413169d235cae01defe7", null ],
    [ "disaccoppiaTrailer", "class_film.html#a6e741e83e292cb8f85712dfd4196d925", null ],
    [ "estendiDataFineRilascio", "class_film.html#acfe82dd1cf9eeecc645ba5159b2ce698", null ],
    [ "rimuoviTrailer", "class_film.html#a804f4e60c7f804ca9934ec81d8cd761a", null ],
    [ "setDataFineRilascio", "class_film.html#aefbbd20e9554d424f553fe5cb9fd6a4f", null ]
];