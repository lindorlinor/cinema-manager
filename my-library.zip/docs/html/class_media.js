var class_media =
[
    [ "calcolaIncasso", "class_media.html#a43348466aebdbe988ad55473b9732c41", null ],
    [ "DurataCampagna", "class_media.html#a0dcb4941c952295b53e3ff31af1e367b", null ],
    [ "estendiDataFineRilascio", "class_media.html#a957bf71135599ba62d4a2b3e41a50a8d", null ],
    [ "FuoriProduzione", "class_media.html#a0f090c2c4806f7f6c2650415edeb81bf", null ],
    [ "IncrementaVisualizzazioni", "class_media.html#a08632b3d774a3f41b2e0ec881130579c", null ]
];