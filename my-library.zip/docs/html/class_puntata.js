var class_puntata =
[
    [ "aggiungiLingua", "class_puntata.html#afbe4686838531a3d54b740cc2c4ade3d", null ],
    [ "associaPodcast", "class_puntata.html#a3b78b39eb440dae6cc8b0402fdb8699c", null ],
    [ "calcolaIncasso", "class_puntata.html#a6038db976491d0a635259472519abbe6", null ],
    [ "estendiDataFineRilascio", "class_puntata.html#a806af1f704b620f35813086d97acb380", null ],
    [ "setDataFineRilascio", "class_puntata.html#a61c96f3fd3392d9f61da1ad8b827223b", null ],
    [ "setDataInizioRilascio", "class_puntata.html#a7a716689f5a17be81e797ff577998d6f", null ]
];