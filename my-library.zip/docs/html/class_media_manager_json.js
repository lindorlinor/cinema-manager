var class_media_manager_json =
[
    [ "clearMediaList", "class_media_manager_json.html#ae8faae75fb9b7cf69540b05a3e01f057", null ],
    [ "clearMediaList", "class_media_manager_json.html#aa4688997d031b16d181dd46859a478cb", null ],
    [ "convertDate", "class_media_manager_json.html#a3de008979a9225a61ee7aa50d4160b2d", null ],
    [ "createFilmFromData", "class_media_manager_json.html#a8f2811cdddce6937e2407447a0236e97", null ],
    [ "findMedia", "class_media_manager_json.html#aa61ccf042986cbee110eae1daab32eaa", null ],
    [ "loadAllData", "class_media_manager_json.html#a0f123f40262c8ec2d5f735c5b2eac1b0", null ],
    [ "loadFilms", "class_media_manager_json.html#ace0546e9d6f239b9117dc347b75af537", null ],
    [ "loadFilmsData", "class_media_manager_json.html#a904175d024f388da5309b3fc2f752af9", null ],
    [ "modified", "class_media_manager_json.html#a1972e66f902064306e88011ba1a87ffd", null ],
    [ "remove", "class_media_manager_json.html#a87bead89d7ca4de3625223cc2a3fdf31", null ],
    [ "saveMedia", "class_media_manager_json.html#ae8a5ddec6e9a70eba5fe3aa7cec1a8cb", null ],
    [ "setNomeCinema", "class_media_manager_json.html#a576d6fa690a19b7e7511a620e48b683e", null ],
    [ "updateCommonField", "class_media_manager_json.html#af2e7e68ec59289885abf66ca0b92519f", null ],
    [ "updateFilm", "class_media_manager_json.html#abae04292e3bb301812c112c3b7ec96aa", null ],
    [ "m_mediaList", "class_media_manager_json.html#a8062731188f28e2d1ccffb7ff79ccef3", null ]
];