var class_cinema_selection_page =
[
    [ "refreshCinemaButtons", "class_cinema_selection_page.html#a2b8adba516bf563a4a87c03ee35f706b", null ]
];