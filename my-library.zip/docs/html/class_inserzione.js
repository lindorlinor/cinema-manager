var class_inserzione =
[
    [ "calcolaIncasso", "class_inserzione.html#a33a821ae28447f76356d8ee67db86f7f", null ],
    [ "estendiDataFineRilascio", "class_inserzione.html#ac21c85015bddc4dd881cf5cc47f15a41", null ]
];