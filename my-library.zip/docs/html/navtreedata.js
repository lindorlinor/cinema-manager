/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "my-library", "index.html", [
    [ "Classi", "annotated.html", [
      [ "Elenco dei tipi composti", "annotated.html", "annotated_dup" ],
      [ "Indice dei tipi composti", "classes.html", null ],
      [ "Gerarchia delle classi", "hierarchy.html", "hierarchy" ],
      [ "Membri dei composti", "functions.html", [
        [ "Tutto", "functions.html", null ],
        [ "Funzioni", "functions_func.html", null ],
        [ "Variabili", "functions_vars.html", null ]
      ] ]
    ] ],
    [ "File", "files.html", [
      [ "Elenco dei file", "files.html", "files_dup" ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"_cinema_button_8h_source.html",
"struct_catch_1_1_string_maker_3_01std_1_1string_01_4.html"
];

var SYNCONMSG = 'cliccare per disabilitare la sincronizzazione del pannello';
var SYNCOFFMSG = 'cliccare per abilitare la sincronizzazione del pannello';
var LISTOFALLMEMBERS = 'Elenco di tutti i membri';