#ifndef TRAILER_H
#define TRAILER_H

#include "Pubblicita.h"
#include "MediaVisitor.h"
class Film; // forward declaration


/**
 * @class Trailer
 * @brief Rappresenta un trailer proiettato al cinema.
 * 
 * Un trailer è una pubblicità proiettata nelle sale del cinema. Un trailer è sempre associato ad un film esistente del cinema. L'associazione è sempre bidirezionale 
 * e l'invariante è soddisfatta in ogni stato stabile del programma.
 * 
 * @note il puntatore a film nella GUI non potrà mai essere null perché è impossibile che l'utente non selezioni alcun film. Tuttavia nel modello è permesso quidi ci sono 
 * delle verifiche attraverso if per controllare questa cosa
 * @see Film
 */
class Trailer : public Pubblicita{
    Film* t_film;
    double calcolaTassoDiStima() const;

public:
    Trailer(const string &titolo, const string &descrizione, year_month_day gg_mm_aaInizioRilascio,
            year_month_day gg_mm_aaFineRilascio, unsigned int durataMinuti, Formato formato, Risoluzione risoluzione,
            unsigned int nProiezioniGiornaliere, Film *film, const string &autore = "Sconosciuto", 
            const string &path = ":/images/default.png");

    ~Trailer();

    /**
     * @brief assegna un film ad un Trailer
     * 
     * @param film 
     * 
     * @see disaccoppiaFilm
     */
    void associaFilm(Film* film); 

    Film* getFilm() const;
    
     /**
     * @brief Imposta la data di fine rilascio del trailer.
     *
     * Imposta la data di fine rilascio del trailer verificando 
     * che questa non sia superiore a quella del film associato. In caso
     * negativo imposta la data di fine del trailer
     * 
     * @param gg_mm_aaFineRilascio La data di fine rilascio del trailer
     * @note non si controlla se il trailer non è fuori produzione perchè non è richiesto per "contratto del metodo", quello è compito di estendi
     * @note nella gui ovviamente dovrà essere avvisato l'utente che la data è maggiore e quindi viene messa quella del film.  
     */ 
    void setDataFineRilascio(year_month_day gg_mm_aaFineRilascio) override; 
   
    /**
     * @brief Aggiorna la data di fine rilascio del trailer con quella del film associato, se non è fuori produzione.
     *
     * Estende la validità del trailer assegnandogli la stessa data di fine rilascio
     * del film associato, a condizione che il trailer non sia contrassegnato come fuori produzione.
     */

    void estendiDataFineRilascio() override;

    /**
     * @brief Calcola l'incasso della distribuzione del trailer al cinema.
     * 
     * L'incasso calcolato è una stima che si basa sulle visualizzazioni del trailer e sulle caratteristiche del flim associato. Il metodo fa uso
     * di @ref calcolaTassoDiStima.
     * @return L'incasso calcolato.
     * @note fare documentazione calcolaTassoDiStima
     */
    double calcolaIncasso() override;
    
    //visitor
    void accept(MediaVisitor* visitor)override;
};

#endif
